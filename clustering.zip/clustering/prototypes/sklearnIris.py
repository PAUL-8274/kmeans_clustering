from sklearn import datasets
from sklearn.cluster import KMeans
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

iris = datasets.load_iris()
print(iris.keys())
df = pd.DataFrame(iris['data'], columns=iris['feature_names'])
df['class'] = iris['target']
print(iris['feature_names'])
cluster = KMeans(n_clusters=3)
cluster.fit(df)
x = df['sepal length (cm)']
y = df['sepal width (cm)']
labels = cluster.labels_
centroids = cluster.cluster_centers_
print(labels)
print(centroids)
fig = plt.figure(1, figsize=(10, 10))
plt.scatter(df['sepal length (cm)'], df['sepal width (cm)'], alpha=0.2, s=100*df['petal length (cm)'], c=df['class'], cmap='viridis')
plt.xlabel(iris['feature_names'][0])
plt.ylabel(iris['feature_names'][1]);
# fig.show()

fig = plt.figure(2, figsize=(10, 10))
plt.scatter(x, y, alpha=0.2, s=100*df['petal length (cm)'], c=labels, cmap='viridis')
plt.xlabel(iris['feature_names'][0])
plt.ylabel(iris['feature_names'][1])
# fig.show()