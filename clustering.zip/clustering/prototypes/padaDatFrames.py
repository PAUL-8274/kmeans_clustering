import pandas as pd

data = [["Utshab", 25], ["Payel", 26], ["Sayantan", 25]]
dt = pd.DataFrame(data, columns=["Name", "Age"])
print(dt)
print(dt.axes)